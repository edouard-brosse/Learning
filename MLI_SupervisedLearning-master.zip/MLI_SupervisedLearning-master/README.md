# Machine learning I: supervised learning
This repository will contain slides, project description, code exercices and
other documents for 5th year students at epitech for
the course "Machine learning I: supervised learning".

## slides

This folder contains the slides for the course.

## code

This folder contains the exercises that are done during the course. This pieces
of code contain mistakes that are to be fixed by the students.
