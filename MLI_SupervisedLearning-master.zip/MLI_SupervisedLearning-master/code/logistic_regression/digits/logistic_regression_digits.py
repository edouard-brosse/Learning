from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression


"""
Add some lines here in order to split the dataset into
train and test classify the handwrtitten digit images to digits values.
"""
