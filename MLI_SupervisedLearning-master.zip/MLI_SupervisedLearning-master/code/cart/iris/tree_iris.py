from pandas.core.base import doc
from sklearn import tree
from sklearn.datasets import load_iris
import graphviz


def main() -> None:
    iris = load_iris()
    """
    Add some lines here
    """

if __name__ == "__main__":
    main()
